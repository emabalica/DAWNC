
var obj;

function displayReminders(){
    let listLength = Object.keys(obj).length;
    console.log(listLength + " objects:");
    let displayedList = document.getElementById("list");

    let keys = Object.keys(obj);

    for(let i=0; i<listLength; i++)
    {
        var listItem = document.createElement("li");
        listItem.setAttribute("id", "ListItem");
        listItem.innerHTML = obj[keys[i]].reminder;
        displayedList.appendChild(listItem);
        console.log(i+": "+obj[keys[i]].reminder);

        let item1= document.getElementById("ListItem");
        var butn1= document.createElement("button");

        //creez butoanele edit si delete
        butn1.innerHTML = "Edit";
        item1.appendChild(butn1);
        var butn2= document.createElement("button");
        butn2.innerHTML = "Delete";
        item1.appendChild(butn2);
        butn1.setAttribute("id", "bt1");
        butn2.setAttribute("id", "bt2");

        //functionalitatea butonului edit
        butn1.addEventListener ("click", function() {
            let rem = prompt("Reminder:", "")
            obj[keys[i]].reminder=rem;
            window.localStorage.setItem("reminder", obj[keys[i]].reminder)
            listItem.innerHTML = obj[keys[i]].reminder;
            console.log(i+": "+obj[keys[i]].reminder);
            alert("modified");

        });
        //delete
        butn2.addEventListener ("click", function() {
            // for(let j=i; j<listLength-1; j++){
            //     obj[keys[j]].reminder=obj[keys[j+1]].reminder;
            // }
            obj[keys[i]].reminder="";
            window.localStorage.setItem("reminder", obj[keys[i]].reminder);

            listItem.innerHTML = obj[keys[i]].reminder;
            console.log(i+": "+obj[keys[i]].reminder);
            alert("deleted");

        });
    }

}

function setLocal()
{
    localStorage.setItem("myToDoList", JSON.stringify(obj));
}

function getLocal()
{
    var intro = localStorage.getItem("myToDoList");
    if (intro!=null) obj = JSON.parse(intro);
    else obj = new Object();
}

let buton = document.getElementById("btn");
buton.onclick = function() {
    let listLength = Object.keys(obj).length;
    listLength++;
    //let newObj = {status: "offline", timestamp: (new Date()).getTime(), reminder: document.getElementById("txt").value,
    //button1:document.getElementsById("bt1"),button2:document.getElementsById("bt2")};
        let newObj = {status: "offline", timestamp: (new Date()).getTime(), reminder: document.getElementById("txt").value};
    obj["o" + listLength] = newObj;
    setLocal(JSON.stringify(obj));

// 2. Append somewhere
    var body = document.getElementsByTagName("body")[0];
    body.appendChild(button);

// 3. Add event handler
    button.addEventListener ("click", function() {
        alert("did something");
    });
    setLocal(JSON.stringify(button));
}


getLocal();
displayReminders();
displayReminders();